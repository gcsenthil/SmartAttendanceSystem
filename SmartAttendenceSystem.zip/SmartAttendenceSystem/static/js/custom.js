function ShowCam() {
    Webcam.set({
        width: 320,
        height: 240,
        image_format: 'jpeg',
        jpeg_quality: 100
    });
    Webcam.attach('#my_camera');
}

function CameraOff(){
Webcam.reset();
 }
function CameraOn(){
ShowCam();
}

function snap() {
    Webcam.snap( function(data_uri) {
        // display results in page
        document.getElementById('results').innerHTML =
        '<img id="image" src="'+ data_uri+'"/>';
      } );
}
function clearMessage(){
var ss=document.getElementById("successArea");
ss.style.visibility='hidden';
}

function upload() {
    var photo = document.getElementById('image').src;
    var photoBlob = dataURItoBlob(photo)
   document.querySelector('#form-student').addEventListener("submit", async function (e) {
    e.preventDefault();
    var form = document.getElementById('form-student');
    var formData=new FormData();
    formData.append('studentId',form["studentId"].value);
    formData.append('FirstName',form["FirstName"].value);
    formData.append('LastName',form["LastName"].value);
    formData.append('Department',form["Department"].value);
    formData.append('EmailId',form["EmailId"].value);
    formData.append('PhoneNumber',form["PhoneNumber"].value);
    formData.append("file", photoBlob);

    const res = await fetch("/api/sform", {
       method: "POST",
       body: formData,
    })
   .then(response => {
    if(response.status==200){
  var ss=document.getElementById("successArea");
ss.style.visibility='visible';
    var msg=document.getElementById('message')
    msg.innerHTML="Saved Sucessfully!!";
     var sid=document.getElementById("studentId");
    sid.value="";
    var firstname=document.getElementById("FirstName");
    firstname.value="";
    var lastname=document.getElementById("LastName");
    lastname.value="";
    var department=document.getElementById("Department");
    department.value="";
    var emailid=document.getElementById("EmailId");
    emailid.value="";
    var phonenumber=document.getElementById("PhoneNumber");
    phonenumber.value="";
    var elem=document.getElementById("results");
    elem.innerHTML="";
    }
   });

    });
}

function dataURItoBlob(dataURI) {
    // convert base64/URLEncoded data component to raw binary data held in a string
    var byteString;
    if (dataURI.split(',')[0].indexOf('base64') >= 0)
        byteString = atob(dataURI.split(',')[1]);
    else
        byteString = unescape(dataURI.split(',')[1]);

    // separate out the mime component
    var mimeString = dataURI.split(',')[0].split(':')[1].split(';')[0];

    // write the bytes of the string to a typed array
    var ia = new Uint8Array(byteString.length);
    for (var i = 0; i < byteString.length; i++) {
        ia[i] = byteString.charCodeAt(i);
    }
    return new Blob([ia], {type:mimeString});
}