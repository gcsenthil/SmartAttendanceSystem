import os
import numpy as np
import cv2
from flaskext.mysql import MySQL
from flask import Flask, render_template, json, request,session,redirect
from werkzeug.security import generate_password_hash, check_password_hash
from PIL import Image
from datetime import datetime
import face_recognition as face_rec
from flask_session import Session


#session variable initalization
app = Flask(__name__)
app.config["SESSION_PERMANENT"] = False
app.config["SESSION_TYPE"] = "filesystem"
Session(app)

#mysql init
mysql = MySQL()
app.config['MYSQL_DATABASE_USER'] = 'root'
app.config['MYSQL_DATABASE_PASSWORD'] = 'Baaju@2604'
app.config['MYSQL_DATABASE_DB'] = 'project'
app.config['MYSQL_DATABASE_HOST'] = 'localhost'
mysql.init_app(app)
studentId=[]



@app.route("/",methods=['GET','POST'])
def login():
    error = None
    if session.get('name')  == None or session.get("name")  == '':
        if request.method == 'POST':
            conn = mysql.connect()
            cursor = conn.cursor()
            _email=request.form['username']
            _password=request.form['password']
            cursor.callproc('sp_checkuser', (_email, _password))
            data = cursor.fetchall()
            if(len(data)==0):
                error = 'Invalid Credentials. Please try again.'
            else:
                if check_password_hash(data[0][3],_password):
                    session["name"] =data[0][1].capitalize()
                    session["emailid"]=data[0][2].capitalize()
                    return render_template('index.html',username=session.get('name') )
                else:
                    error = 'Invalid Credentials. Please try again.'
    else:
        return render_template('index.html', username=session.get('name'))
    return render_template('login.html', error= ( '' if error is None else error ))


@app.route('/studentform')
def studentform():
    if session.get('name') != None and session.get("name") != '':
        return render_template('studentform.html',username=session.get('name'))
    else:
        return render_template('login.html')

@app.route('/signup')
def signup():
         return render_template('signup.html')

@app.route('/report')
def report():
    if session.get('name') != None and session.get("name") != '':
        conn = mysql.connect()
        cursor = conn.cursor()
        _email = session.get('emailid')
        cursor.callproc('sp_getReportbyTeacher', (_email,))
        data = cursor.fetchall()
        if(len(data)>0):
            return render_template('report.html',data=data,username=session.get('name'))
        else:
            return render_template('message.html',message="No Records Found!!",username=session.get('name'))
    else:
        return render_template('login.html')

@app.route('/signout')
def signout():
    if(session.get("name")!=''):
        session.clear()
    return redirect('/')

def findEncoding(images) :
    imgEncodings = []
    for img in images :
        img = cv2.cvtColor(img, cv2.COLOR_BGR2RGB)
        if(len(face_rec.face_encodings(img))>0):
            encodeimg = face_rec.face_encodings(img)[0]
            imgEncodings.append(encodeimg)
    return imgEncodings
def findEncode(image) :
    imgEncodings = []
    images = cv2.cvtColor(image, cv2.COLOR_BGR2RGB)
    if(len(face_rec.face_encodings(image))>0):
       encodeimg = face_rec.face_encodings(image)[0]
       imgEncodings.append(encodeimg)
    return imgEncodings

def write_file(data, filename):
    with open(filename, 'wb') as file:
        file.write(data)

def getImageList():
    knowImageList = []
    conn = mysql.connect()
    cursor = conn.cursor()
    cursor.callproc('get_studentinfo')
    data = cursor.fetchall()
    for d in data:
        write_file(d[6],d[1]+".jpg")
        img=cv2.imread(d[1]+".jpg")
        knowImageList.append(img)
        os.remove(d[1]+".jpg")
        studentId.append(d[0])
    return knowImageList

imgList=getImageList()
encodeListKnown=findEncoding(imgList)

@app.route('/api/attendence',methods=['POST'])
def attendence():
    _file = request.files['file']
    _createby = session["emailid"]
    image = Image.open(_file)
    now = datetime.now()
    dt_string = now.strftime("%d_%m_%Y_%H_%M_%S")
    image.save(dt_string+'.jpg')
    img=cv2.imread(dt_string+'.jpg')
    imgS = cv2.resize(img, (0, 0), None, 0.80, 0.80)
    imgS = cv2.cvtColor(imgS, cv2.COLOR_BGR2RGB)
    facelocCurrFrame = face_rec.face_locations(imgS)
    encodeCurrFrame = face_rec.face_encodings(imgS, facelocCurrFrame)
    os.remove(dt_string+'.jpg')
    for encodeFace, faceLoc in zip(encodeCurrFrame, facelocCurrFrame):
            matches = face_rec.compare_faces(encodeListKnown, encodeFace)
            #for i in range(len(matches)):
            #if(matches[i]==True):
            faceDis = face_rec.face_distance(encodeListKnown, encodeFace)
            matchIndex = np.argmin(faceDis)
            if matches[matchIndex] and round(faceDis[matchIndex],1)<=0.5:
                print(faceDis)
                conn = mysql.connect()
                cursor = conn.cursor()
                Id = studentId[matchIndex]
                cursor.callproc('sp_attendence', (Id,_createby,))
                data = cursor.fetchall()
                if len(data) == 0:
                   conn.commit()
    return json.dumps({'message': 'Processing!'})
#return json.dumps({'message': 'Processing Image!'})

@app.route('/api/sform',methods=['POST'])
def sform():
    _file = request.files['file']
    image = Image.open(_file)
    _firstName=request.form['FirstName']
    if(_firstName == ''):
        _firstName="unknowN";
    _studentId = request.form['studentId']
    _lastName = request.form['LastName']
    _department = request.form['Department']
    _emailId = request.form['EmailId']
    _phoneNumber = request.form['PhoneNumber']
    _createby=session["emailid"]
    image.save(_firstName+'.jpeg')
    img=cv2.imread(_firstName+'.jpeg')
    photo= convertToBinaryData(_firstName+'.jpeg')
    os.remove(_firstName + '.jpeg')
    if _studentId and _emailId and _firstName and photo:
        conn = mysql.connect()
        cursor = conn.cursor()
        cursor.callproc('sp_createStudentInfo', (_studentId,_firstName,_lastName,_department,_emailId,_phoneNumber,photo,_createby))
        data = cursor.fetchall()
        if len(data) == 0:
            conn.commit()
            ec=findEncode(img)
            if len(ec) >0:
                encodeListKnown.append(ec[0])
                studentId.append(_studentId)
            return json.dumps({'message': 'Student information saved successfully !'})
        else:
            return json.dumps({'error': str(data[0])})

    else:
        return json.dumps({'html': '<span>Enter the required fields</span>'})


def convertToBinaryData(filename):
    # Convert digital data to binary format
    with open(filename, 'rb') as file:
        binaryData = file.read()
    return binaryData

@app.route('/api/signup',methods=['POST'])
def postsignup():
    _name = request.form['inputName']
    _email = request.form['inputEmail']
    _password = request.form['inputPassword']

    if _name and _email and _password:
        conn = mysql.connect()
        cursor = conn.cursor()
        _hashed_password = generate_password_hash(_password)
        cursor.callproc('sp_createUser', (_name, _email, _hashed_password))
        data = cursor.fetchall()
        if len(data) == 0:
            conn.commit()
            return json.dumps({'message': 'User created successfully !'})
        else:
            return json.dumps({'error': str(data[0])})
    else:
        return json.dumps({'html': '<span>Enter the required fields</span>'})
if __name__ == "__main__":
    app.run()